#ifndef ADC_PROBE_H
#define ADC_PROBE_H

#include "main.h"

void  Adc_Init(void);

float Adc_PinToVin(float pin_volts);   /* ولتاژ پایه‌ی PC4 -> ولتاژ ورودی (با تصحیح صفر و ضریب تقسیم) */
/* مثل بالا ولی خطی و بدون کلمپ زیر صفر/خم زانو - مخصوص اندازه‌گیری‌های AC (تست
 * سیم‌کشی). Adc_PinToVin برای ولت‌متر DC ساخته شده: زیر Adc_GetZero() رو کاملاً
 * صاف (دقیقاً صفر) می‌کنه که روی یک موج متناوب کوچیک کل نصف پایین موج رو از
 * بین می‌بره و امضای فرکانسی رو خراب می‌کنه. */
float Adc_PinToVinLinear(float pin_volts);
/* حداقل گام بین دو نمونه‌ی Adc_CapturePC4 (سیکل CPU، ~1.3us @280MHz). گام واقعی = این + gap_cycles.
 * Adc_CapturePC4 مقدار برگشتی = (گام واقعی × n)؛ یعنی فاصله‌ی نمونه‌ها دقیقاً یکنواخته: dt = ret / n / SystemCoreClock */
#define ADC_CAP_MIN_STEP_CYC  360U
/* n نمونه‌ی سریع از PC4 (بدون میانگین). gap_cycles = فاصله‌ی اضافه بین نمونه‌ها (سیکل CPU).
 * خروجی: تعداد سیکل CPU کل، 0 = خطا */
uint32_t Adc_CapturePC4(uint16_t *dst, uint32_t n, uint32_t gap_cycles);
uint32_t Adc_CapturePB0(uint16_t *dst, uint32_t n, uint32_t gap_cycles);   /* مثل بالا ولی مستقیم از گره‌ی ورودی پروب ۱ (بدون OPAMP) */
uint32_t Adc_CapturePA6(uint16_t *dst, uint32_t n, uint32_t gap_cycles);   /* بافر پروب ۲ (PA6) ، مسیر تخت */
/* ---- شمارش لبه‌ی دیجیتال روی PB0 (گره‌ی ورودی Probe1) برای تست سیم‌کشی ≥ 1 MHz ----
 * Adc_Pb0DigitalBegin: PB0 رو موقتاً ورودی دیجیتال می‌کنه ؛ Adc_Pb0DigitalEnd: دوباره آنالوگ (OPAMP/ADC).
 * Adc_Pb0EdgeBurst: window_cyc سیکل CPU (با وقفه‌ی بسته) پایه رو پشت‌سرهم می‌خونه.
 *   خروجی: سیکل واقعی پنجره (0 = خطا) ، rise = تعداد لبه‌ی بالارونده ، ones = تعداد نمونه‌ی HIGH ، tot = کل نمونه‌ها */
void     Adc_Pb0DigitalBegin(void);
void     Adc_Pb0DigitalEnd(void);
uint32_t Adc_Pb0EdgeBurst(uint32_t window_cyc, uint32_t *rise, uint32_t *ones, uint32_t *tot);
float Adc_GetVin(void);   /* ولتاژ ورودی با تصحیح صفر */
float Adc_GetZero(void);
void  Adc_ResetZero(void);
uint8_t Adc_CalibrateZero(void);   /* ولتاژ واقعی ورودی دستگاه (از PC4، خروجی OPAMP) */
float Adc_GetProbe1Dc(void);   /* ولتاژ DC واقعی روی Probe1 (از PB0 بدون آفست OPAMP ، با ضریب تقسیم) */
float Adc_GetPB0(void);   /* ولتاژ تقسیم‌شده قبل از بافر، ADC1_IN9 */
float Adc_GetPC4(void);   /* خروجی OPAMP1، ADC1_IN4 */
float Adc_GetPB1(void);   /* ADC1_IN5، خروجی U7A، بعد از کم کردن آفست */
float Adc_GetPA6(void);   /* ADC1_IN3 */
float Adc_GetSupply(void);   /* ولتاژ تغذیه‌ی برد (VCC) از PA2 × 11 */
float Adc_GetSupplyScale(void);   /* ضریب فعلی PA2 -> VCC */
void  Adc_AdjustSupply(float dv); /* ولتاژ نمایشی رو به اندازه‌ی dv کم/زیاد می‌کنه (کالیبراسیون) */
float Adc_GetPA2(void);   /* ADC1_IN14 */
float Adc_GetPC1(void);   /* ADC2_IN11 */
float Adc_ReadPinVolts(ADC_HandleTypeDef *hadc, uint32_t channel);



void Adc_SelfTest(void);
extern volatile uint32_t g_vrefint_raw;
extern volatile float    g_vdda;

#endif
